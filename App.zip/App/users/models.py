from django.db import models
from django.contrib.auth.models import AbstractUser                                       


# teacher/student
class Status(models.Model):
	title = models.CharField(max_length = 256)

	def __str__(self):
		return self.title 


# inheriting from AbstractUser class will allow us to have the same built in fields of user already implemented 
class CustomUser(AbstractUser): 
    status = models.ForeignKey(Status, on_delete = models.CASCADE, blank = True, null = True)
	    

    def __str__(self):
        return self.username





