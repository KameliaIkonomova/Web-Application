from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import CustomUser, Status 


class CustomUserAdmin(UserAdmin):
	# fieldsets that will show in the admin panel for the users
	fieldsets = (
			(None, {
				'fields': ('username', 'password')
				}),
			('Personal info', {
				'fields': ('first_name', 'last_name', 'email')
				}),
			('Permissions', {
				'fields': (
				'is_active', 'is_staff', 'is_superuser',
				'groups', 'user_permissions'
				)
			}),
			('Important dates', {
				'fields': ('last_login', 'date_joined')
				}),
			('Additional info', {
				# here are the fields we can implement, currently we are adding only status field
			'fields': ('status', )
			})
	    )

# registering the models to our database
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(Status)