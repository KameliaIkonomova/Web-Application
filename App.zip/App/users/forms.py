from django import forms
from django.contrib.auth.forms import UserCreationForm              
  

from .models import CustomUser 


# this is the form we will register the user
class UserRegisterForm(UserCreationForm):
    class Meta:
        model = CustomUser                                              
        fields = ['username', 'password1', 'password2', 'status']   
